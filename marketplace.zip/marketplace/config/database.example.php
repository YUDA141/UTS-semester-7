<?php
/**
 * CONTOH konfigurasi database.
 *
 * Cara pakai:
 *   1. Salin file ini menjadi  config/database.php
 *   2. Isi dengan data database dari panel InfinityFree
 *      (menu "MySQL Databases": hostname, nama DB, username, password).
 *   3. JANGAN pernah meng-commit config/database.php ke GitHub
 *      (sudah dimasukkan ke .gitignore).
 */

define('DB_HOST', 'sqlXXX.infinityfree.com'); // contoh: sql306.infinityfree.com
define('DB_USER', 'if0_XXXXXXXX');            // username MySQL dari panel hosting
define('DB_PASS', 'ISI_PASSWORD_DATABASE');   // password MySQL dari panel hosting
define('DB_NAME', 'if0_XXXXXXXX_marketplace');// nama database yang sudah dibuat

// Opsional: isi bila aplikasi berada di subfolder dan URL tidak terdeteksi otomatis
// define('BASE_URL', '/marketplace');
